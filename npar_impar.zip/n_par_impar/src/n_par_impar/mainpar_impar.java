package n_par_impar;

import java.util.Scanner;

public class mainpar_impar {

	public static void main(String[] args) {
		
		Scanner teclado=new Scanner(System.in);
		int numero;
		
		System.out.println(" INGRESE UN NUMERO ");
		numero=teclado.nextInt();
		
		if (numero % 2==0) 
		{
			System.out.println( "  EL NUMERO QUE INGRESO ES PAR : " +numero );
		}
		else 
		{
			System.out.println( " EL NUMERO QUE INGRESO ES IMPAR : " +numero );
			
		}
		
	}

}
