package año_bisiesto;

import java.util.Scanner;
public class main_año {

	public static void main(String[] args) {
		
		Scanner teclado= new Scanner(System.in);
		int año;
		
		System.out.println(" INGRESE EL AÑÑO ");
		año=teclado.nextInt();
		
		if ((año % 4==0 && año % 100 !=0) || año % 400==0) 
		{
			System.out.println("EL AÑO QUE INGRESO ES BISIESTO : " +año);
			
		}
		else 
		{
			System.out.println("EL AÑO QUE INGRESO NO ES BISIESTO : " +año);
		}
	}

}
