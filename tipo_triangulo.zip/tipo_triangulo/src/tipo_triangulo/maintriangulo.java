package tipo_triangulo;

import java.util.Scanner;

public class maintriangulo {

	public static void main(String[] args) {
	
    Scanner teclado=new Scanner(System.in);
		
		int a,b,c;
		
		System.out.println("INGRESE EL PRIMER LADO DEL TRIANGULO");
		a=teclado.nextInt();
		
		System.out.println("INGRESE EL SEGUNDO  LADO DEL TRIANGULO");
		b=teclado.nextInt();
		
		System.out.println("INGRESE EL TERCER  LADO DEL TRIANGULO");
		c=teclado.nextInt();
		
		if(a==b && b==c) 
		{
			System.out.println("EL TRIANGULO ES EQUILATERO");
		}
		else if (a==b || a==c || b==c)
		{
			System.out.println("EL TRIANGULO ES ISOCELES ");
		}
		else
		{
			System.out.println("EL TRIANGULO ES ESCALENO ");
		}
		
	}

	}
